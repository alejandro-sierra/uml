
import java.util.*;

/**
 * 
 */
public class Directivo extends Empleado {

    /**
     * Default constructor
     */
    public Directivo() {
    }

    /**
     * 
     */
    private void categoria : int;

}