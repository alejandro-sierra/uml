
import java.util.*;

/**
 * 
 */
public class Cliente extends Persona {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    private void telefono: String;


}