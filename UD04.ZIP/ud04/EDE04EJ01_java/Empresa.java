
import java.util.*;

/**
 * 
 */
public class Empresa {

    /**
     * Default constructor
     */
    public Empresa() {
    }

    /**
     * 
     */
    private void Empleados: Lista;

    /**
     * 
     */
    private Lista Clientes;



    /**
     * 
     */
    public void mostrarDatos() {
        // TODO implement here
    }

}