
import java.util.*;

/**
 * 
 */
public class Empleado extends Persona {

    /**
     * Default constructor
     */
    public Empleado() {
    }

    /**
     * 
     */
    private double sueldoBruto;


}