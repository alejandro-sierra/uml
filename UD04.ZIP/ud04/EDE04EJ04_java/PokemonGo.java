
import java.util.*;

/**
 * 
 */
public class PokemonGo {

    /**
     * Default constructor
     */
    public PokemonGo() {
    }


    /**
     * 
     */
    public void AtacarOtro() {
        // TODO implement here
    }

    /**
     * @param args 
     * @return
     */
    public static void main(String args) {
        // TODO implement here
        return null;
    }

}