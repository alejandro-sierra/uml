
import java.util.*;

/**
 * 
 */
public class Pocion {

    /**
     * Default constructor
     */
    public Pocion() {
    }

    /**
     * 
     */
    private void pocion: int;

    /**
     * 
     */
    private void superpocion: int;

    /**
     * 
     */
    private void hiperpocion: int;

    /**
     * 
     */
    private void ultrapocion: int;


}