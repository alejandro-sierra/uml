
import java.util.*;

/**
 * 
 */
public class Pokeball {

    /**
     * Default constructor
     */
    public Pokeball() {
    }

    /**
     * 
     */
    private void ball: String;

    /**
     * 
     */
    private void pokeball: int;

    /**
     * 
     */
    private void superball: int;

    /**
     * 
     */
    private void ultraball: int;

    /**
     * 
     */
    private void masterball: int;


}