
import java.util.*;

/**
 * 
 */
public class Jugador {

    /**
     * Default constructor
     */
    public Jugador() {
    }

    /**
     * 
     */
    private void usuario: String;

    /**
     * 
     */
    private void nombre: String;

    /**
     * 
     */
    private void nivel: int;

    /**
     * 
     */
    private void experiencia: int;

    /**
     * 
     */
    private void contador: int;







    /**
     * @return
     */
    public void ganarExperiencia() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void subirNivel() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public boolean tieneXPparaSigNivel() {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public String getRecompensasSubirNivel() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public void robarPokemon() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public void pokeparada() {
        // TODO implement here
        return null;
    }

}