
import java.util.*;

/**
 * 
 */
public class Habilidades {

    /**
     * Default constructor
     */
    public Habilidades() {
    }

    /**
     * 
     */
    private void habilidad1: String;

    /**
     * 
     */
    private void habilidad2: String;

    /**
     * 
     */
    private void fuerzaHabiliad1: int;

    /**
     * 
     */
    private void fuerzaHabilidad2: int;



}